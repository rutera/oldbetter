require 'network_interface/version'

module NetworkInterface  
end

require 'network_interface_ext'
